
public class TestAcc
 {
public static void main(String[] args){
	MyFrame2 mf2=new MyFrame2("First");
}
}
