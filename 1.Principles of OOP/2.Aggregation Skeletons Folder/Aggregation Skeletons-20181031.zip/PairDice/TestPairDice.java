
public class TestPairDice
 {
public static void main(String[] args){
	MyFrame2b mf2=new MyFrame2b("First");
}
}
