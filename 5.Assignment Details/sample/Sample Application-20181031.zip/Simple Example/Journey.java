
class Journey{
	private String destination;
	public Journey(String dest){
		destination=dest;}
	
	public String readDestination(){return destination;}
}

