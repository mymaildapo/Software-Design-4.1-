
public class SearchTargetTest {

    public static boolean searchTarget(int value,int t){
    	return false;
    }
    public static void main(String[] args) {
	  int number=Console.readInt("Enter Value:");
          int target=Console.readInt("Enter Target:");
      System.out.println("Res= "+ searchTarget(number,target));
    }
}

