
public class OddTest {

    public static int countOdd(int value){
    	return 0;
    }
    public static void main(String[] args) {
	  int number=Console.readInt("Enter Value:");
      System.out.println("Res= "+ countOdd(number));
    }
}

