
public class AddEvenTest {

    public static int addEven(int value){
    	return 0;
    }
    public static void main(String[] args) {
	  int number=Console.readInt("Enter Value:");
          System.out.println("Res= "+ addEven(number));
    }
}

