
public class CountTargetTest {

    public static int countTarget(int value,int t){
    	return 0;
    }
    public static void main(String[] args) {
	  int number=Console.readInt("Enter Value:");
          int target=Console.readInt("Enter Target:");
      System.out.println("Res= "+ countTarget(number,target));
    }
}

