
public class MaxTest {

    public static int max(int value){
    	return 0;
    }
    public static void main(String[] args) {
	  int number=Console.readInt("Enter Value:");
          System.out.println("Res= "+ max(number));
    }
}

